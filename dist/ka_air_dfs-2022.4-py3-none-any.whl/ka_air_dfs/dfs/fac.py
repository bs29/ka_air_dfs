"""
Utilities for DAG Factory for tasks
"""


class DagFac:

    cmd_ix = 0
    sw_cmd_ix = False
